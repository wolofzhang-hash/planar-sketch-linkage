# -*- coding: utf-8 -*-
"""Headless simulation utilities for optimization and run evaluation."""

from __future__ import annotations

import json
import math
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

from .constraints_registry import ConstraintRegistry
from .expression_service import eval_signal_expression
from .geometry import angle_between, clamp_angle_rad, build_spline_samples, closest_point_on_samples
from .solver import ConstraintSolver
from .scipy_kinematics import SciPyKinematicSolver
from .exudyn_kinematics import ExudynKinematicSolver
from .sim_common_queries import SimulationQueryLoadMixin


@dataclass
class SweepSettings:
    start: float
    end: float
    step: float


class HeadlessModel(SimulationQueryLoadMixin):
    def __init__(self, snapshot: Dict[str, Any], case_spec: Dict[str, Any]):
        self.points: Dict[int, Dict[str, Any]] = {}
        self.links: Dict[int, Dict[str, Any]] = {}
        self.angles: Dict[int, Dict[str, Any]] = {}
        self.splines: Dict[int, Dict[str, Any]] = {}
        self.bodies: Dict[int, Dict[str, Any]] = {}
        self.coincides: Dict[int, Dict[str, Any]] = {}
        self.point_lines: Dict[int, Dict[str, Any]] = {}
        self.point_splines: Dict[int, Dict[str, Any]] = {}

        self.driver: Dict[str, Any] = self._default_driver()
        self.drivers: List[Dict[str, Any]] = []
        self.output: Dict[str, Any] = self._default_output()
        self.outputs: List[Dict[str, Any]] = []
        self.measures: List[Dict[str, Any]] = []
        self.loads: List[Dict[str, Any]] = []
        self.load_measures: List[Dict[str, Any]] = []
        self.friction_joints: List[Dict[str, Any]] = []

        self._sim_zero_input_rad: Optional[float] = None
        self._sim_zero_output_rad: Optional[float] = None
        self._sim_zero_meas_deg: Dict[str, float] = {}
        self._sim_zero_meas_len: Dict[str, float] = {}

        self._load_snapshot(snapshot)
        self._apply_case_spec(case_spec)
        self.mark_sim_start_pose()

    @staticmethod
    def _default_driver() -> Dict[str, Any]:
        return {
            "enabled": False,
            "type": "angle",
            "pivot": None,
            "tip": None,
            "rad": 0.0,
            "plid": None,
            "s_base": 0.0,
            "value": 0.0,
        }

    @staticmethod
    def _default_output() -> Dict[str, Any]:
        return {"enabled": False, "pivot": None, "tip": None, "rad": 0.0}

    @staticmethod
    def _normalize_driver(data: Dict[str, Any]) -> Dict[str, Any]:
        return {
            "enabled": bool(data.get("enabled", True)),
            "type": str(data.get("type", "angle")),
            "pivot": data.get("pivot"),
            "tip": data.get("tip"),
            "rad": float(data.get("rad", 0.0) or 0.0),
            "plid": data.get("plid"),
            "s_base": float(data.get("s_base", 0.0) or 0.0),
            "value": float(data.get("value", 0.0) or 0.0),
        }

    @staticmethod
    def _normalize_output(data: Dict[str, Any]) -> Dict[str, Any]:
        return {
            "enabled": bool(data.get("enabled", True)),
            "pivot": data.get("pivot"),
            "tip": data.get("tip"),
            "rad": float(data.get("rad", 0.0) or 0.0),
        }

    def _active_drivers(self) -> List[Dict[str, Any]]:
        return [d for d in self.drivers if d.get("enabled", False)]

    def _active_outputs(self) -> List[Dict[str, Any]]:
        return [o for o in self.outputs if o.get("enabled", False)]

    def _sync_primary_driver(self) -> None:
        if self.drivers:
            self.driver = dict(self.drivers[0])
        else:
            self.driver = self._default_driver()

    def _sync_primary_output(self) -> None:
        if self.outputs:
            self.output = dict(self.outputs[0])
        else:
            self.output = self._default_output()

    def _primary_driver(self) -> Optional[Dict[str, Any]]:
        return self.drivers[0] if self.drivers else None

    def _primary_output(self) -> Optional[Dict[str, Any]]:
        return self.outputs[0] if self.outputs else None

    def _load_snapshot(self, data: Dict[str, Any]) -> None:
        self.points = {
            int(p["id"]): {
                "x": float(p.get("x", 0.0)),
                "y": float(p.get("y", 0.0)),
                "fixed": bool(p.get("fixed", False)),
                "hidden": bool(p.get("hidden", False)),
            }
            for p in data.get("points", []) or []
        }

        constraints = data.get("constraints", None)
        if constraints:
            lks, angs, _spls_unused, coincs, pls, pss, _pds = ConstraintRegistry.split_constraints(constraints)
            spls = data.get("splines", []) or []
        else:
            lks = data.get("links", []) or []
            angs = data.get("angles", []) or []
            spls = data.get("splines", []) or []
            coincs = data.get("coincides", []) or []
            pls = data.get("point_lines", []) or []
            pss = data.get("point_splines", []) or []

        self.links = {
            int(l["id"]): {
                "i": int(l.get("i", -1)),
                "j": int(l.get("j", -1)),
                "L": float(l.get("L", 0.0)),
                "ref": bool(l.get("ref", False)),
                "over": False,
            }
            for l in lks
        }
        self.angles = {
            int(a["id"]): {
                "i": int(a.get("i", -1)),
                "j": int(a.get("j", -1)),
                "k": int(a.get("k", -1)),
                "deg": float(a.get("deg", 0.0)),
                "rad": math.radians(float(a.get("deg", 0.0))),
                "enabled": bool(a.get("enabled", True)),
                "over": False,
            }
            for a in angs
        }
        self.splines = {
            int(s.get("id", -1)): {
                "points": list(s.get("points", [])),
                "hidden": bool(s.get("hidden", False)),
                "closed": bool(s.get("closed", False)),
            }
            for s in spls
        }
        self.coincides = {
            int(c["id"]): {
                "a": int(c.get("a", -1)),
                "b": int(c.get("b", -1)),
                "enabled": bool(c.get("enabled", True)),
                "over": False,
            }
            for c in coincs
        }
        point_lines: Dict[int, Dict[str, Any]] = {}
        for pl in pls:
            plid = int(pl.get("id", -1))
            entry = {
                "p": int(pl.get("p", -1)),
                "i": int(pl.get("i", -1)),
                "j": int(pl.get("j", -1)),
                "enabled": bool(pl.get("enabled", True)),
                "over": False,
            }
            if "s" in pl or "s_expr" in pl:
                entry["s"] = float(pl.get("s", 0.0))
                entry["s_expr"] = str(pl.get("s_expr", ""))
                if pl.get("name"):
                    entry["name"] = str(pl.get("name", ""))
            point_lines[plid] = entry
        self.point_lines = point_lines
        self.point_splines = {
            int(ps["id"]): {
                "p": int(ps.get("p", -1)),
                "s": int(ps.get("s", -1)),
                "enabled": bool(ps.get("enabled", True)),
                "over": False,
            }
            for ps in pss
        }

        self.bodies = {
            int(b.get("id", -1)): {
                "rigid_edges": list(b.get("rigid_edges", [])),
            }
            for b in data.get("bodies", []) or []
        }

        driver = data.get("driver", {}) or {}
        output = data.get("output", {}) or {}
        drivers_list = data.get("drivers", None)
        outputs_list = data.get("outputs", None)
        self.drivers = []
        if isinstance(drivers_list, list) and drivers_list:
            for drv in drivers_list:
                if isinstance(drv, dict):
                    normalized = self._normalize_driver(drv)
                    if "rad" not in drv:
                        normalized["_needs_rad"] = True
                    self.drivers.append(normalized)
        elif isinstance(driver, dict):
            legacy_driver = self._normalize_driver(driver)
            if legacy_driver.get("enabled"):
                if "rad" not in driver:
                    legacy_driver["_needs_rad"] = True
                self.drivers.append(legacy_driver)

        for drv in self.drivers:
            if not drv.pop("_needs_rad", False):
                continue
            if drv.get("type") != "angle":
                continue
            piv = drv.get("pivot")
            tip = drv.get("tip")
            if piv is not None and tip is not None:
                ang = self.get_angle_rad(int(piv), int(tip))
                if ang is not None:
                    drv["rad"] = float(ang)
        self._sync_primary_driver()

        self.outputs = []
        if isinstance(outputs_list, list) and outputs_list:
            for out in outputs_list:
                if isinstance(out, dict):
                    normalized = self._normalize_output(out)
                    if "rad" not in out:
                        normalized["_needs_rad"] = True
                    self.outputs.append(normalized)
        elif isinstance(output, dict):
            legacy_output = self._normalize_output(output)
            if legacy_output.get("enabled"):
                if "rad" not in output:
                    legacy_output["_needs_rad"] = True
                self.outputs.append(legacy_output)

        for out in self.outputs:
            if not out.pop("_needs_rad", False):
                continue
            piv = out.get("pivot")
            tip = out.get("tip")
            if piv is not None and tip is not None:
                ang = self.get_angle_rad(int(piv), int(tip))
                if ang is not None:
                    out["rad"] = float(ang)
        self._sync_primary_output()
        self.measures = list(data.get("measures", []) or [])
        self.loads = list(data.get("loads", []) or [])
        self.load_measures = list(data.get("load_measures", []) or [])
        self.friction_joints = list(data.get("friction_joints", []) or [])

    def _point_line_current_s(self, pl: Dict[str, Any]) -> float:
        try:
            p_id = int(pl.get("p", -1))
            i_id = int(pl.get("i", -1))
            j_id = int(pl.get("j", -1))
        except Exception:
            return 0.0
        if p_id not in self.points or i_id not in self.points or j_id not in self.points:
            return 0.0
        pp = self.points[p_id]
        pa = self.points[i_id]
        pb = self.points[j_id]
        ax, ay = float(pa["x"]), float(pa["y"])
        bx, by = float(pb["x"]), float(pb["y"])
        px, py = float(pp["x"]), float(pp["y"])
        abx, aby = bx - ax, by - ay
        ab_len = math.hypot(abx, aby)
        if ab_len < 1e-12:
            return 0.0
        ux, uy = abx / ab_len, aby / ab_len
        return (px - ax) * ux + (py - ay) * uy

    def _apply_case_spec(self, case_spec: Dict[str, Any]) -> None:
        driver = case_spec.get("driver")
        drivers_list = case_spec.get("drivers")
        output = case_spec.get("output")
        outputs_list = case_spec.get("outputs")
        if isinstance(drivers_list, list):
            self.drivers = [self._normalize_driver(d) for d in drivers_list if isinstance(d, dict)]
            self._sync_primary_driver()
        elif isinstance(driver, dict):
            self.drivers = [self._normalize_driver(driver)]
            self._sync_primary_driver()
        if isinstance(outputs_list, list):
            self.outputs = [self._normalize_output(o) for o in outputs_list if isinstance(o, dict)]
            self._sync_primary_output()
        elif isinstance(output, dict):
            self.outputs = [self._normalize_output(output)]
            self._sync_primary_output()
        loads = case_spec.get("loads")
        if isinstance(loads, list):
            self.loads = [dict(ld) for ld in loads]
        friction_joints = case_spec.get("friction_joints")
        if isinstance(friction_joints, list):
            self.friction_joints = [dict(fj) for fj in friction_joints]
        measurements = case_spec.get("measurements", {}) or {}
        measures = measurements.get("measures")
        if isinstance(measures, list):
            self.measures = [dict(m) for m in measures]
        load_measures = measurements.get("load_measures")
        if isinstance(load_measures, list):
            self.load_measures = [dict(m) for m in load_measures]

    def mark_sim_start_pose(self) -> None:
        self._sim_zero_input_rad = self._get_input_angle_abs_rad()
        self._sim_zero_output_rad = self._get_output_angle_abs_rad()
        self._sim_zero_meas_deg = {}
        self._sim_zero_meas_len = {}
        for name, val, unit in self.get_measure_values(abs_values=True):
            if val is None:
                continue
            if unit == "deg":
                self._sim_zero_meas_deg[name] = float(val)
            elif unit == "mm":
                self._sim_zero_meas_len[name] = float(val)

    @staticmethod
    def _point_line_offset_name(pl: Dict[str, Any]) -> str:
        try:
            p = int(pl.get("p", -1))
            i = int(pl.get("i", -1))
            j = int(pl.get("j", -1))
        except Exception:
            return "point line s"
        return f"s P{p} on (P{i}-P{j})"

    def get_input_angle_deg(self) -> Optional[float]:
        ang = self._get_input_angle_abs_rad()
        if ang is None:
            return None
        abs_deg = math.degrees(ang)
        if self._sim_zero_input_rad is None:
            return abs_deg
        base_deg = math.degrees(self._sim_zero_input_rad)
        return self._rel_deg(abs_deg, base_deg)

    def get_output_angle_deg(self) -> Optional[float]:
        ang = self._get_output_angle_abs_rad()
        if ang is None:
            return None
        abs_deg = math.degrees(ang)
        if self._sim_zero_output_rad is None:
            return abs_deg
        base_deg = math.degrees(self._sim_zero_output_rad)
        return self._rel_deg(abs_deg, base_deg)

    def get_driver_angles_deg(self) -> List[Optional[float]]:
        angles: List[Optional[float]] = []
        if not self.drivers:
            return angles
        for idx, drv in enumerate(self.drivers):
            if not drv.get("enabled", True):
                angles.append(None)
                continue
            if str(drv.get("type", "angle")) == "angle":
                piv = drv.get("pivot")
                tip = drv.get("tip")
                if piv is None or tip is None:
                    angles.append(None)
                    continue
                ang = self.get_angle_rad(int(piv), int(tip))
                if ang is None:
                    angles.append(None)
                    continue
                abs_deg = math.degrees(ang)
                if idx == 0 and self._sim_zero_input_rad is not None:
                    base_deg = math.degrees(self._sim_zero_input_rad)
                    angles.append(self._rel_deg(abs_deg, base_deg))
                else:
                    angles.append(abs_deg)
            else:
                val = drv.get("value")
                try:
                    angles.append(float(val))
                except Exception:
                    angles.append(None)
        return angles

    def snapshot_state(self) -> Dict[str, Any]:
        return {
            "points": {pid: (float(p["x"]), float(p["y"])) for pid, p in self.points.items()},
            "drivers": [
                {"rad": float(d.get("rad", 0.0) or 0.0), "value": float(d.get("value", 0.0) or 0.0)}
                for d in self.drivers
            ],
            "outputs": [float(o.get("rad", 0.0)) for o in self.outputs],
        }

    def apply_state_snapshot(self, snapshot: Dict[str, Any]) -> None:
        for pid, pos in (snapshot.get("points") or {}).items():
            if pid in self.points:
                self.points[pid]["x"] = float(pos[0])
                self.points[pid]["y"] = float(pos[1])
        driver_items = snapshot.get("drivers") or []
        # Backward compatible: legacy snapshots stored a list of rads.
        for idx, it in enumerate(driver_items):
            if idx >= len(self.drivers):
                continue
            if isinstance(it, dict):
                self.drivers[idx]["rad"] = float(it.get("rad", 0.0) or 0.0)
                if "value" in it:
                    self.drivers[idx]["value"] = float(it.get("value", 0.0) or 0.0)
            else:
                self.drivers[idx]["rad"] = float(it)
        output_rads = snapshot.get("outputs") or []
        for idx, rad in enumerate(output_rads):
            if idx < len(self.outputs):
                self.outputs[idx]["rad"] = float(rad)
        self._sync_primary_driver()
        self._sync_primary_output()

    def get_measure_values(self, abs_values: bool = False) -> List[tuple[str, Optional[float], str]]:
        out: List[tuple[str, Optional[float], str]] = []
        base_values: Dict[int, tuple[str, Optional[float], str]] = {}
        signals: Dict[str, float] = {}

        for idx, m in enumerate(self.measures):
            nm = str(m.get("name", ""))
            mtype = str(m.get("type", "")).lower()
            abs_deg: Optional[float] = None
            if mtype == "angle":
                ang = self.get_angle_rad(int(m.get("pivot")), int(m.get("tip")))
                abs_deg = None if ang is None else math.degrees(ang)
            elif mtype == "joint":
                ang = self.get_joint_angle_rad(int(m.get("i")), int(m.get("j")), int(m.get("k")))
                abs_deg = None if ang is None else math.degrees(ang)
            elif mtype == "translation":
                try:
                    plid = int(m.get("plid", -1))
                except (TypeError, ValueError):
                    plid = -1
                pl = self.point_lines.get(plid)
                if pl is None:
                    base_values[idx] = (nm, None, "mm")
                    continue
                nm = str(nm) or self._point_line_offset_name(pl)
                try:
                    sval = float(pl.get("s", 0.0))
                except (TypeError, ValueError):
                    sval = None
                if sval is not None and (not abs_values) and nm in self._sim_zero_meas_len:
                    base_values[idx] = (nm, sval - float(self._sim_zero_meas_len[nm]), "mm")
                else:
                    base_values[idx] = (nm, sval, "mm")
                if nm and base_values[idx][1] is not None:
                    signals[nm] = float(base_values[idx][1])
                continue
            elif mtype == "expression":
                continue
            else:
                continue

            if abs_deg is None:
                base_values[idx] = (nm, None, "deg")
            elif abs_values:
                base_values[idx] = (nm, abs_deg, "deg")
            elif nm in self._sim_zero_meas_deg:
                base_values[idx] = (nm, self._rel_deg(abs_deg, float(self._sim_zero_meas_deg[nm])), "deg")
            else:
                base_values[idx] = (nm, abs_deg, "deg")
            if nm and base_values[idx][1] is not None:
                signals[nm] = float(base_values[idx][1])

        for nm, val in self.get_load_measure_values():
            if nm and val is not None:
                signals[str(nm)] = float(val)

        for idx, m in enumerate(self.measures):
            if idx in base_values:
                out.append(base_values[idx])
                continue
            mtype = str(m.get("type", "")).lower()
            if mtype != "expression":
                continue
            nm = str(m.get("name", ""))
            expr = str(m.get("expr", ""))
            unit = str(m.get("unit", ""))
            val, err = eval_signal_expression(expr, signals)
            if err:
                out.append((nm, None, unit))
            else:
                out.append((nm, float(val), unit))
                if nm:
                    signals[nm] = float(val)
        return out

    def _build_quasistatic_constraints(self, point_ids: List[int]) -> List[Any]:
        idx_map = {pid: idx for idx, pid in enumerate(point_ids)}
        funcs: List[Any] = []

        def _xy(q: np.ndarray, pid: int) -> tuple[float, float]:
            idx = idx_map[pid]
            return float(q[2 * idx]), float(q[2 * idx + 1])

        for pid in point_ids:
            p = self.points[pid]
            if not bool(p.get("fixed", False)):
                continue
            x0, y0 = float(p["x"]), float(p["y"])
            funcs.append(lambda q, pid=pid, x0=x0: _xy(q, pid)[0] - x0)
            funcs.append(lambda q, pid=pid, y0=y0: _xy(q, pid)[1] - y0)

        for c in self.coincides.values():
            if not bool(c.get("enabled", True)):
                continue
            a = int(c.get("a", -1))
            b = int(c.get("b", -1))
            if a not in idx_map or b not in idx_map:
                continue
            funcs.append(lambda q, a=a, b=b: _xy(q, a)[0] - _xy(q, b)[0])
            funcs.append(lambda q, a=a, b=b: _xy(q, a)[1] - _xy(q, b)[1])

        for pl in self.point_lines.values():
            if not bool(pl.get("enabled", True)):
                continue
            p_id = int(pl.get("p", -1))
            i_id = int(pl.get("i", -1))
            j_id = int(pl.get("j", -1))
            if p_id not in idx_map or i_id not in idx_map or j_id not in idx_map:
                continue

            def _pol(q: np.ndarray, p_id=p_id, i_id=i_id, j_id=j_id) -> float:
                px, py = _xy(q, p_id)
                ax, ay = _xy(q, i_id)
                bx, by = _xy(q, j_id)
                abx, aby = bx - ax, by - ay
                denom = math.hypot(abx, aby)
                if denom < 1e-9:
                    return 0.0
                return ((px - ax) * (-aby) + (py - ay) * abx) / denom

            funcs.append(_pol)

        for ps in self.point_splines.values():
            if not bool(ps.get("enabled", True)):
                continue
            p_id = int(ps.get("p", -1))
            s_id = int(ps.get("s", -1))
            if p_id not in idx_map or s_id not in self.splines:
                continue
            spline = self.splines[s_id]
            cp_ids = [pid for pid in spline.get("points", []) if pid in idx_map]
            if len(cp_ids) < 2:
                continue

            def _pos(q: np.ndarray, p_id=p_id, cp_ids=cp_ids, spline=spline) -> float:
                px, py = _xy(q, p_id)
                samples = build_spline_samples(
                    [_xy(q, cid) for cid in cp_ids],
                    closed=bool(spline.get("closed", False)),
                )
                _, _, _, _, dist2 = closest_point_on_samples(px, py, samples)
                return math.sqrt(dist2)

            funcs.append(_pos)

        body_edges: List[Tuple[int, int, float]] = []
        for b in self.bodies.values():
            body_edges.extend(b.get("rigid_edges", []))
        for (i, j, L) in body_edges:
            if i not in idx_map or j not in idx_map:
                continue

            def _len(q: np.ndarray, i=i, j=j, L=L) -> float:
                xi, yi = _xy(q, i)
                xj, yj = _xy(q, j)
                return math.hypot(xj - xi, yj - yi) - float(L)

            funcs.append(_len)

        for l in self.links.values():
            if l.get("ref", False):
                continue
            i, j = int(l.get("i", -1)), int(l.get("j", -1))
            if i not in idx_map or j not in idx_map:
                continue

            def _len(q: np.ndarray, i=i, j=j, L=l["L"]) -> float:
                xi, yi = _xy(q, i)
                xj, yj = _xy(q, j)
                return math.hypot(xj - xi, yj - yi) - float(L)

            funcs.append(_len)

        for a in self.angles.values():
            if not bool(a.get("enabled", True)):
                continue
            i, j, k = int(a.get("i", -1)), int(a.get("j", -1)), int(a.get("k", -1))
            if i not in idx_map or j not in idx_map or k not in idx_map:
                continue
            target = float(a.get("rad", 0.0))

            def _ang(q: np.ndarray, i=i, j=j, k=k, target=target) -> float:
                xi, yi = _xy(q, i)
                xj, yj = _xy(q, j)
                xk, yk = _xy(q, k)
                v1x, v1y = xi - xj, yi - yj
                v2x, v2y = xk - xj, yk - yj
                if math.hypot(v1x, v1y) < 1e-12 or math.hypot(v2x, v2y) < 1e-12:
                    return 0.0
                cur = angle_between(v1x, v1y, v2x, v2y)
                return clamp_angle_rad(cur - target)

            funcs.append(_ang)

        active_drivers = self._active_drivers()
        active_outputs = self._active_outputs()
        if active_drivers:
            for drv in active_drivers:
                if drv.get("type") != "angle":
                    continue
                piv = drv.get("pivot")
                tip = drv.get("tip")
                if piv in idx_map and tip in idx_map:
                    target = float(drv.get("rad", 0.0))

                    def _drv(q: np.ndarray, piv=piv, tip=tip, target=target) -> float:
                        px, py = _xy(q, int(piv))
                        tx, ty = _xy(q, int(tip))
                        dx, dy = tx - px, ty - py
                        if abs(dx) + abs(dy) < 1e-12:
                            return 0.0
                        return clamp_angle_rad(math.atan2(dy, dx) - target)

                    funcs.append(_drv)
        elif active_outputs:
            for out in active_outputs:
                piv = out.get("pivot")
                tip = out.get("tip")
                if piv in idx_map and tip in idx_map:
                    target = float(out.get("rad", 0.0))

                    def _odrv(q: np.ndarray, piv=piv, tip=tip, target=target) -> float:
                        px, py = _xy(q, int(piv))
                        tx, ty = _xy(q, int(tip))
                        dx, dy = tx - px, ty - py
                        if abs(dx) + abs(dy) < 1e-12:
                            return 0.0
                        return clamp_angle_rad(math.atan2(dy, dx) - target)

                    funcs.append(_odrv)

        return funcs

    def compute_quasistatic_joint_loads(self) -> List[Dict[str, Any]]:
        point_ids = sorted(list(self.points.keys()))
        if not point_ids:
            return []
        idx_map = {pid: idx for idx, pid in enumerate(point_ids)}
        q = np.array([coord for pid in point_ids for coord in (self.points[pid]["x"], self.points[pid]["y"])], dtype=float)
        ndof = len(q)
        f_ext = np.zeros(ndof, dtype=float)
        torque_map: Dict[int, float] = {pid: 0.0 for pid in point_ids}
        for load in self.loads:
            pid = int(load.get("pid", -1))
            if pid not in self.points:
                continue
            idx = idx_map[pid]
            fx, fy, mz = self._resolve_load_components(load, q, idx_map)
            f_ext[2 * idx] += fx
            f_ext[2 * idx + 1] += fy
            if abs(mz) > 0.0:
                torque_map[pid] = torque_map.get(pid, 0.0) + float(mz)

        funcs = self._build_quasistatic_constraints(point_ids)
        if not funcs:
            out = []
            for idx, pid in enumerate(point_ids):
                fx = -float(f_ext[2 * idx])
                fy = -float(f_ext[2 * idx + 1])
                out.append({"pid": pid, "fx": fx, "fy": fy, "mag": math.hypot(fx, fy)})
            return out

        def eval_constraints(qvec: np.ndarray) -> np.ndarray:
            return np.array([fn(qvec) for fn in funcs], dtype=float)

        eps = 1e-6
        c0 = eval_constraints(q)
        m = int(c0.size)
        J = np.zeros((m, ndof), dtype=float)
        for i in range(ndof):
            dq = np.zeros_like(q)
            dq[i] = eps
            fp = eval_constraints(q + dq)
            fm = eval_constraints(q - dq)
            J[:, i] = (fp - fm) / (2.0 * eps)

        if J.size == 0:
            lam = np.zeros(m, dtype=float)
        else:
            try:
                lam, *_ = np.linalg.lstsq(J.T, -f_ext, rcond=None)
            except np.linalg.LinAlgError:
                lam = np.zeros(m, dtype=float)

        joint_loads: List[Dict[str, Any]] = []
        lam = np.asarray(lam, dtype=float)
        for idx, pid in enumerate(point_ids):
            fx = -float(f_ext[2 * idx])
            fy = -float(f_ext[2 * idx + 1])
            mag = math.hypot(fx, fy)
            joint_loads.append({"pid": pid, "fx": fx, "fy": fy, "mag": mag})
        return joint_loads

    def drive_to_deg(self, deg: float, iters: int = 80) -> None:
        if not self._active_drivers() and not self._active_outputs():
            return
        primary_driver = self._primary_driver()
        primary_output = self._primary_output()
        if primary_driver and primary_driver.get("enabled"):
            dtype = str(primary_driver.get("type", "angle"))
            if dtype == "translation":
                # Interpret `deg` as a linear value (mm) for point-on-line translation drivers.
                target_s = float(deg)
                plid = primary_driver.get("plid")
                pl = self.point_lines.get(plid) if plid in self.point_lines else None
                if pl is None:
                    base_s = float(primary_driver.get("s_base", 0.0) or 0.0)
                else:
                    base_s = float(primary_driver.get("s_base", self._point_line_current_s(pl)) or 0.0)
                    pl["s"] = target_s
                primary_driver["value"] = float(target_s - base_s)
                self.drivers[0] = primary_driver
                self._sync_primary_driver()
            else:
                if self._sim_zero_input_rad is not None:
                    target = float(self._sim_zero_input_rad) + math.radians(float(deg))
                else:
                    target = math.radians(float(deg))
                primary_driver["rad"] = float(target)
                self.drivers[0] = primary_driver
                self._sync_primary_driver()
        elif primary_output and primary_output.get("enabled"):
            if self._sim_zero_output_rad is not None:
                target = float(self._sim_zero_output_rad) + math.radians(float(deg))
            else:
                target = math.radians(float(deg))
            primary_output["rad"] = float(target)
            self.outputs[0] = primary_output
            self._sync_primary_output()
        self.solve_constraints(iters=iters)

    def solve_constraints(self, iters: int = 60) -> None:
        for l in self.links.values():
            l["over"] = False
        for a in self.angles.values():
            a["over"] = False
        for c in self.coincides.values():
            c["over"] = False
        for pl in self.point_lines.values():
            pl["over"] = False
        for ps in self.point_splines.values():
            ps["over"] = False

        body_edges: List[Tuple[int, int, float]] = []
        for b in self.bodies.values():
            body_edges.extend(b.get("rigid_edges", []))

        driven_pids: set[int] = set()
        active_drivers = self._active_drivers()
        active_outputs = self._active_outputs()
        drive_sources: List[Dict[str, Any]] = []
        if active_drivers:
            for drv in active_drivers:
                entry = dict(drv)
                entry["mode"] = "driver"
                drive_sources.append(entry)
        elif active_outputs:
            for out in active_outputs:
                entry = {
                    "mode": "output",
                    "type": "angle",
                    "pivot": out.get("pivot"),
                    "tip": out.get("tip"),
                    "rad": out.get("rad", 0.0),
                }
                drive_sources.append(entry)

        for drv in drive_sources:
            if str(drv.get("type", "angle")) == "translation":
                plid = drv.get("plid")
                if plid in self.point_lines:
                    p_id = self.point_lines[plid].get("p")
                    if p_id is not None:
                        driven_pids.add(int(p_id))
                continue
            tip = drv.get("tip")
            if tip is not None:
                driven_pids.add(int(tip))

        driver_length_pairs: set[frozenset[int]] = set()
        for drv in drive_sources:
            piv = drv.get("pivot")
            tip = drv.get("tip")
            if piv is not None and tip is not None:
                driver_length_pairs.add(frozenset({int(piv), int(tip)}))

        translation_targets: Dict[int, float] = {}
        for drv in drive_sources:
            if str(drv.get("type", "angle")) != "translation":
                continue
            plid = drv.get("plid")
            if plid not in self.point_lines:
                continue
            pl = self.point_lines[plid]
            base_s = float(drv.get("s_base", self._point_line_current_s(pl)) or 0.0)
            offset = float(drv.get("value", 0.0) or 0.0)
            translation_targets[int(plid)] = base_s + offset

        for _ in range(int(iters)):
            for drv in drive_sources:
                if str(drv.get("type", "angle")) == "translation":
                    continue
                piv = drv.get("pivot")
                tip = drv.get("tip")
                if piv is None or tip is None:
                    continue
                piv = int(piv); tip = int(tip)
                if piv in self.points and tip in self.points:
                    piv_pt = self.points[piv]
                    tip_pt = self.points[tip]
                    lock_piv = bool(piv_pt.get("fixed", False))
                    lock_tip = bool(tip_pt.get("fixed", False))
                    ConstraintSolver.enforce_driver_angle(
                        piv_pt,
                        tip_pt,
                        float(drv.get("rad", 0.0)),
                        lock_piv,
                        lock_tip=lock_tip,
                    )

            for plid, target_s in translation_targets.items():
                pl = self.point_lines.get(plid)
                if not pl or not bool(pl.get("enabled", True)):
                    continue
                p_id = int(pl.get("p", -1))
                i_id = int(pl.get("i", -1))
                j_id = int(pl.get("j", -1))
                if p_id not in self.points or i_id not in self.points or j_id not in self.points:
                    continue
                pp = self.points[p_id]
                pa = self.points[i_id]
                pb = self.points[j_id]
                lock_p = bool(pp.get("fixed", False))
                lock_a = bool(pa.get("fixed", False))
                lock_b = bool(pb.get("fixed", False))
                ConstraintSolver.solve_point_on_line_offset(
                    pp,
                    pa,
                    pb,
                    float(target_s),
                    lock_p,
                    lock_a,
                    lock_b,
                    tol=1e-6,
                )

            for c in self.coincides.values():
                if not bool(c.get("enabled", True)):
                    continue
                a = int(c.get("a", -1))
                b = int(c.get("b", -1))
                if a not in self.points or b not in self.points:
                    continue
                pa = self.points[a]
                pb = self.points[b]
                ax, ay = float(pa["x"]), float(pa["y"])
                bx, by = float(pb["x"]), float(pb["y"])
                lock_a = bool(pa.get("fixed", False))
                lock_b = bool(pb.get("fixed", False))
                if lock_a and lock_b:
                    if (ax - bx) * (ax - bx) + (ay - by) * (ay - by) > 1e-6:
                        c["over"] = True
                    continue
                if lock_a and not lock_b:
                    pb["x"], pb["y"] = ax, ay
                elif lock_b and not lock_a:
                    pa["x"], pa["y"] = bx, by
                else:
                    mx = 0.5 * (ax + bx)
                    my = 0.5 * (ay + by)
                    pa["x"], pa["y"] = mx, my
                    pb["x"], pb["y"] = mx, my

            for plid, pl in self.point_lines.items():
                if not bool(pl.get("enabled", True)):
                    continue
                p_id = int(pl.get("p", -1))
                i_id = int(pl.get("i", -1))
                j_id = int(pl.get("j", -1))
                if p_id not in self.points or i_id not in self.points or j_id not in self.points:
                    continue
                pp = self.points[p_id]
                pa = self.points[i_id]
                pb = self.points[j_id]
                lock_p = bool(pp.get("fixed", False)) or (p_id in driven_pids)
                lock_a = bool(pa.get("fixed", False)) or (i_id in driven_pids)
                lock_b = bool(pb.get("fixed", False)) or (j_id in driven_pids)
                if plid in translation_targets:
                    ok = ConstraintSolver.solve_point_on_line_offset(
                        pp,
                        pa,
                        pb,
                        float(translation_targets[plid]),
                        lock_p,
                        lock_a,
                        lock_b,
                        tol=1e-6,
                    )
                elif "s" in pl:
                    ok = ConstraintSolver.solve_point_on_line(pp, pa, pb, lock_p, lock_a, lock_b, tol=1e-6)
                else:
                    ok = ConstraintSolver.solve_point_on_line(pp, pa, pb, lock_p, lock_a, lock_b, tol=1e-6)
                if not ok:
                    pl["over"] = True

            for ps in self.point_splines.values():
                if not bool(ps.get("enabled", True)):
                    continue
                p_id = int(ps.get("p", -1))
                s_id = int(ps.get("s", -1))
                if p_id not in self.points or s_id not in self.splines:
                    continue
                spline = self.splines[s_id]
                cp_ids = [pid for pid in spline.get("points", []) if pid in self.points]
                if len(cp_ids) < 2:
                    continue
                pp = self.points[p_id]
                cps = [self.points[cid] for cid in cp_ids]
                lock_p = bool(pp.get("fixed", False)) or (p_id in driven_pids)
                lock_controls = []
                for cid in cp_ids:
                    lock_controls.append(bool(self.points[cid].get("fixed", False)) or (cid in driven_pids))
                ok = ConstraintSolver.solve_point_on_spline(
                    pp,
                    cps,
                    lock_p,
                    lock_controls,
                    tol=1e-6,
                    closed=bool(spline.get("closed", False)),
                )
                if not ok:
                    ps["over"] = True

            for (i, j, L) in body_edges:
                if i not in self.points or j not in self.points:
                    continue
                p1, p2 = self.points[i], self.points[j]
                pair = frozenset({i, j})
                allow_move_driven = (pair in driver_length_pairs)
                lock1 = bool(p1.get("fixed", False)) or ((i in driven_pids) and (not allow_move_driven))
                lock2 = bool(p2.get("fixed", False)) or ((j in driven_pids) and (not allow_move_driven))
                ConstraintSolver.solve_length(p1, p2, float(L), lock1, lock2, tol=1e-6)

            for l in self.links.values():
                if l.get("ref", False):
                    continue
                i, j = l["i"], l["j"]
                if i not in self.points or j not in self.points:
                    continue
                p1, p2 = self.points[i], self.points[j]
                pair = frozenset({i, j})
                allow_move_driven = (pair in driver_length_pairs)
                lock1 = bool(p1.get("fixed", False)) or ((i in driven_pids) and (not allow_move_driven))
                lock2 = bool(p2.get("fixed", False)) or ((j in driven_pids) and (not allow_move_driven))
                ok = ConstraintSolver.solve_length(p1, p2, float(l["L"]), lock1, lock2, tol=1e-6)
                if not ok:
                    l["over"] = True

            for a in self.angles.values():
                if not a.get("enabled", True):
                    continue
                i, j, k = a["i"], a["j"], a["k"]
                if i not in self.points or j not in self.points or k not in self.points:
                    continue
                pi, pj, pk = self.points[i], self.points[j], self.points[k]
                lock_i = bool(pi.get("fixed", False)) or (i in driven_pids)
                lock_j = bool(pj.get("fixed", False)) or (j in driven_pids)
                lock_k = bool(pk.get("fixed", False)) or (k in driven_pids)
                ok = ConstraintSolver.solve_angle(pi, pj, pk, float(a["rad"]), lock_i, lock_j, lock_k, tol=1e-5)
                if not ok:
                    a["over"] = True

    def solve_constraints_scipy(self, max_nfev: int = 200) -> tuple[bool, str]:
        try:
            ok, msg, _cost = SciPyKinematicSolver.solve(self, max_nfev=max_nfev)
            return ok, msg
        except Exception as exc:
            return False, str(exc)

    def solve_constraints_exudyn(self, max_iters: int = 80) -> tuple[bool, str]:
        try:
            ok, msg = ExudynKinematicSolver.solve(self, max_iters=max_iters, distance_only=True)
            return ok, msg
        except Exception as exc:
            return False, ExudynKinematicSolver._format_exception(exc)

    def _check_over_flags_only(self) -> None:
        return

    def max_constraint_error(self) -> Tuple[float, Dict[str, float]]:
        max_len = 0.0
        max_ang = 0.0
        max_coin = 0.0
        max_pl = 0.0
        max_ps = 0.0

        body_edges: List[Tuple[int, int, float]] = []
        for b in self.bodies.values():
            body_edges.extend(b.get("rigid_edges", []))
        for (i, j, L) in body_edges:
            if i in self.points and j in self.points:
                p1, p2 = self.points[i], self.points[j]
                d = math.hypot(p2["x"] - p1["x"], p2["y"] - p1["y"])
                max_len = max(max_len, abs(d - float(L)))

        for l in self.links.values():
            if bool(l.get("ref", False)):
                continue
            i, j = int(l.get("i", -1)), int(l.get("j", -1))
            if i in self.points and j in self.points:
                p1, p2 = self.points[i], self.points[j]
                d = math.hypot(p2["x"] - p1["x"], p2["y"] - p1["y"])
                max_len = max(max_len, abs(d - float(l.get("L", 0.0))))

        for a in self.angles.values():
            if not bool(a.get("enabled", True)):
                continue
            i, j, k = int(a.get("i", -1)), int(a.get("j", -1)), int(a.get("k", -1))
            if i in self.points and j in self.points and k in self.points:
                pi, pj, pk = self.points[i], self.points[j], self.points[k]
                v1x, v1y = pi["x"] - pj["x"], pi["y"] - pj["y"]
                v2x, v2y = pk["x"] - pj["x"], pk["y"] - pj["y"]
                if math.hypot(v1x, v1y) > 1e-12 and math.hypot(v2x, v2y) > 1e-12:
                    cur = angle_between(v1x, v1y, v2x, v2y)
                    err = abs(clamp_angle_rad(cur - float(a.get("rad", 0.0))))
                    max_ang = max(max_ang, err)

        for c in self.coincides.values():
            if not bool(c.get("enabled", True)):
                continue
            a_id, b_id = int(c.get("a", -1)), int(c.get("b", -1))
            if a_id in self.points and b_id in self.points:
                pa, pb = self.points[a_id], self.points[b_id]
                max_coin = max(max_coin, math.hypot(pa["x"] - pb["x"], pa["y"] - pb["y"]))

        for pl in self.point_lines.values():
            if not bool(pl.get("enabled", True)):
                continue
            p_id, i_id, j_id = int(pl.get("p", -1)), int(pl.get("i", -1)), int(pl.get("j", -1))
            if p_id in self.points and i_id in self.points and j_id in self.points:
                pp, pa, pb = self.points[p_id], self.points[i_id], self.points[j_id]
                ax, ay = float(pa["x"]), float(pa["y"])
                bx, by = float(pb["x"]), float(pb["y"])
                px, py = float(pp["x"]), float(pp["y"])
                abx, aby = bx - ax, by - ay
                denom = math.hypot(abx, aby)
                if denom > 1e-12:
                    if "s" in pl:
                        ux, uy = abx / denom, aby / denom
                        target_x = ax + ux * float(pl.get("s", 0.0))
                        target_y = ay + uy * float(pl.get("s", 0.0))
                        dist = math.hypot(px - target_x, py - target_y)
                    else:
                        dist = abs((px - ax) * (-aby) + (py - ay) * abx) / denom
                    max_pl = max(max_pl, dist)

        for ps in self.point_splines.values():
            if not bool(ps.get("enabled", True)):
                continue
            p_id = int(ps.get("p", -1))
            s_id = int(ps.get("s", -1))
            if p_id not in self.points or s_id not in self.splines:
                continue
            cp_ids = [pid for pid in self.splines[s_id].get("points", []) if pid in self.points]
            if len(cp_ids) < 2:
                continue
            pts = [(self.points[cid]["x"], self.points[cid]["y"]) for cid in cp_ids]
            samples = build_spline_samples(pts, samples_per_segment=16, closed=bool(self.splines[s_id].get("closed", False)))
            if len(samples) < 2:
                continue
            px, py = float(self.points[p_id]["x"]), float(self.points[p_id]["y"])
            _cx, _cy, _seg_idx, _t_seg, dist2 = closest_point_on_samples(px, py, samples)
            max_ps = max(max_ps, math.sqrt(dist2))

        max_err = max(max_len, max_ang, max_coin, max_pl, max_ps)
        return max_err, {
            "length": max_len,
            "angle": max_ang,
            "coincide": max_coin,
            "point_line": max_pl,
            "point_spline": max_ps,
        }


def simulate_case(
    model_snapshot: Dict[str, Any],
    case_spec: Dict[str, Any],
) -> Tuple[List[Dict[str, Any]], Dict[str, Any], Dict[str, Any]]:
    model = HeadlessModel(model_snapshot, case_spec)

    sweep = case_spec.get("sweep", {}) or {}
    start = float(sweep.get("start_deg", sweep.get("start", 0.0)))
    end = float(sweep.get("end_deg", sweep.get("end", 0.0)))
    step_count = sweep.get("step_count", None)
    if step_count is None:
        step = float(sweep.get("step_deg", sweep.get("step", 1.0)))
        step = abs(step) if step != 0 else 1.0
        if end < start:
            step = -step
        step_count = None
    else:
        step = None
        try:
            step_count = int(round(float(step_count)))
        except Exception:
            step_count = 1
        step_count = max(step_count, 1)
    adaptive = bool(sweep.get("adaptive", True))
    dtheta_min_deg = float(sweep.get("dtheta_min_deg", sweep.get("min_step_deg", 0.05)))
    dtheta_max_deg = float(sweep.get("dtheta_max_deg", sweep.get("max_step_deg", 2.0)))
    err_good = float(sweep.get("err_good", 1e-10))
    err_ok = float(sweep.get("err_ok", 1e-7))
    grow = float(sweep.get("grow", 1.35))
    shrink = float(sweep.get("shrink", 0.5))
    max_retries_per_step = int(sweep.get("max_retries_per_step", 8))
    if dtheta_min_deg <= 0:
        dtheta_min_deg = 1e-6
    if dtheta_max_deg <= 0:
        dtheta_max_deg = max(dtheta_min_deg, 1e-3)
    if dtheta_max_deg < dtheta_min_deg:
        dtheta_max_deg = dtheta_min_deg

    solver = case_spec.get("solver", {}) or {}
    solver_name = str(solver.get("name") or ("scipy" if solver.get("use_scipy", False) else "pbd")).lower()
    if solver_name not in ("pbd", "scipy", "exudyn"):
        solver_name = "pbd"
    max_nfev = int(solver.get("max_nfev", 200))
    pbd_iters = int(solver.get("pbd_iters", 80))
    hard_err_tol = float(solver.get("hard_err_tol", 1e-3))
    treat_point_spline_as_soft = bool(solver.get("treat_point_spline_as_soft", False))
    solver_error = ""
    solver_error_log: List[str] = []

    if solver_name == "scipy":
        ok, _msg = model.solve_constraints_scipy(max_nfev=max_nfev)
        if not ok:
            if _msg:
                detail = f"scipy: {_msg}"
                if not solver_error:
                    solver_error = detail
                if detail not in solver_error_log:
                    solver_error_log.append(detail)
            model.solve_constraints(iters=pbd_iters)
    elif solver_name == "exudyn":
        ok, _msg = model.solve_constraints_exudyn(max_iters=pbd_iters)
        if not ok:
            if _msg:
                detail = f"exudyn: {_msg}"
                if not solver_error:
                    solver_error = detail
                if detail not in solver_error_log:
                    solver_error_log.append(detail)
            model.solve_constraints(iters=pbd_iters)
    else:
        model.solve_constraints(iters=pbd_iters)
    model.mark_sim_start_pose()

    frames: List[Dict[str, Any]] = []
    reason = ""
    success = True
    tol = 1e-12

    # --- Angle convention (policy) ---
    # The whole application uses degrees and *relative* angles.
    # - Input curve x is always "relative input deg" (0 at sim-start).
    # - Output curve y is always "relative output deg" (0 at sim-start).
    #
    # The controller already implements this via mark_sim_start_pose():
    #   - drive_to_deg() interprets deg as relative-to-sim-start
    #   - get_input_angle_deg()/get_output_angle_deg() return relative values
    #
    # Therefore we do NOT support absolute mode here. Any old "angle_mode" is
    # ignored to avoid silent mismatches.
    angle_mode = "relative"

    # Branch tracking for closed-chain linkages (e.g. 4-bar):
    # keep the same assembly branch by monitoring the sign of a reference
    # oriented area. If the sign flips (away from singularity), we treat the
    # frame as invalid (strongly penalized by the optimizer).
    base_branch_sign: Optional[int] = None
    branch_eps = 1e-9
    try:
        drv = None
        outp = None
        if hasattr(model, "_primary_driver"):
            drv = model._primary_driver()
        if drv is None:
            drv = getattr(model, "driver", None)
        if hasattr(model, "_primary_output"):
            outp = model._primary_output()
        if outp is None:
            outp = getattr(model, "output", None)
        if isinstance(drv, dict) and isinstance(outp, dict):
            a = drv.get("pivot")
            b = drv.get("tip")
            c = outp.get("tip")
            if a is not None and b is not None and c is not None:
                pts0 = model.snapshot_state().get("points") or {}
                pa = pts0.get(int(a)); pb = pts0.get(int(b)); pc = pts0.get(int(c))
                if pa is not None and pb is not None and pc is not None:
                    ax, ay = float(pa[0]), float(pa[1])
                    bx, by = float(pb[0]), float(pb[1])
                    cx, cy = float(pc[0]), float(pc[1])
                    area2 = (bx - ax) * (cy - ay) - (by - ay) * (cx - ax)
                    if abs(area2) > branch_eps:
                        base_branch_sign = 1 if area2 > 0 else -1
    except Exception:
        base_branch_sign = None

    def try_solve(cmd_deg: float) -> Tuple[bool, float, str, float]:
        nonlocal solver_error
        ok_local = True
        msg_local = ""
        deg = float(cmd_deg)
        if solver_name == "scipy":
            model.drive_to_deg(deg, iters=0)
            ok_local, msg_local = model.solve_constraints_scipy(max_nfev=max_nfev)
            if not ok_local:
                if msg_local:
                    detail = f"scipy: {msg_local}"
                    if not solver_error:
                        solver_error = detail
                    if detail not in solver_error_log:
                        solver_error_log.append(detail)
                model.solve_constraints(iters=pbd_iters)
        elif solver_name == "exudyn":
            model.drive_to_deg(deg, iters=0)
            ok_local, msg_local = model.solve_constraints_exudyn(max_iters=pbd_iters)
            if not ok_local:
                if msg_local:
                    detail = f"exudyn: {msg_local}"
                    if not solver_error:
                        solver_error = detail
                    if detail not in solver_error_log:
                        solver_error_log.append(detail)
                model.solve_constraints(iters=pbd_iters)
        else:
            model.drive_to_deg(deg, iters=pbd_iters)

        max_err, detail = model.max_constraint_error()
        hard_err_local = max(
            detail.get("length", 0.0),
            detail.get("angle", 0.0),
            detail.get("coincide", 0.0),
            detail.get("point_line", 0.0),
        )
        if not treat_point_spline_as_soft:
            hard_err_local = max(hard_err_local, detail.get("point_spline", 0.0))
        return bool(ok_local), float(hard_err_local), msg_local, float(cmd_deg)

    def _record_frame(frame_idx: int, hard_err_value: float, ok_value: bool, retries: int, dtheta_used: float, cmd_deg: float) -> None:
        step_success = bool(ok_value) and hard_err_value <= hard_err_tol
        branch_jump = 0
        branch_sign = 0
        # Branch tracking (assembly branch consistency)
        try:
            if base_branch_sign is not None:
                drv = None
                outp = None
                if hasattr(model, "_primary_driver"):
                    drv = model._primary_driver()
                if drv is None:
                    drv = getattr(model, "driver", None)
                if hasattr(model, "_primary_output"):
                    outp = model._primary_output()
                if outp is None:
                    outp = getattr(model, "output", None)
                if isinstance(drv, dict) and isinstance(outp, dict):
                    a = drv.get("pivot")
                    b = drv.get("tip")
                    c = outp.get("tip")
                    if a is not None and b is not None and c is not None:
                        pts = model.snapshot_state().get("points") or {}
                        pa = pts.get(int(a)); pb = pts.get(int(b)); pc = pts.get(int(c))
                        if pa is not None and pb is not None and pc is not None:
                            ax, ay = float(pa[0]), float(pa[1])
                            bx, by = float(pb[0]), float(pb[1])
                            cx, cy = float(pc[0]), float(pc[1])
                            area2 = (bx - ax) * (cy - ay) - (by - ay) * (cx - ax)
                            if abs(area2) > branch_eps:
                                branch_sign = 1 if area2 > 0 else -1
                                if branch_sign != base_branch_sign:
                                    branch_jump = 1
                                    step_success = False
        except Exception:
            pass
        if not step_success:
            nonlocal success, reason
            success = False
            if not reason:
                reason = "constraint_error" if branch_jump == 0 else "branch_flip"
        # Record input/output in the curve-target domain: relative degrees.
        try:
            input_deg = float(model.get_input_angle_deg())
        except Exception:
            input_deg = float(cmd_deg)
        try:
            output_deg = float(model.get_output_angle_deg())
        except Exception:
            output_deg = float(model.get_output_angle_deg()) if hasattr(model, "get_output_angle_deg") else 0.0
        rec: Dict[str, Any] = {
            "time": frame_idx,
            "solver": solver_name,
            "success": step_success,
            "input_deg": input_deg,
            "output_deg": output_deg,
            "driver_deg": model.get_driver_angles_deg(),
            "hard_err": hard_err_value,
            "branch_jump": branch_jump,
            "branch_sign": branch_sign,
            "dtheta_deg": dtheta_used,
            "retries": retries,
        }
        # Optional: record point positions for fast GUI replay.
        # This makes animation playback much faster because the UI can apply
        # point coordinates directly instead of re-solving constraints every frame.
        if bool(case_spec.get("record_pose", False)):
            try:
                pts = model.snapshot_state().get("points") or {}
                # Store as a compact JSON-friendly list.
                rec["pose_points"] = [[int(pid), float(xy[0]), float(xy[1])] for pid, xy in pts.items()]
            except Exception:
                pass
        for nm, val, _unit in model.get_measure_values():
            rec[nm] = val
        for nm, val in model.get_load_measure_values():
            rec[nm] = val
        frames.append(rec)

    if not adaptive:
        degrees: List[float] = []
        if step_count is None:
            cur = start
            if step > 0:
                while cur <= end + 1e-9:
                    degrees.append(cur)
                    cur += step
            else:
                while cur >= end - 1e-9:
                    degrees.append(cur)
                    cur += step
        else:
            for idx in range(step_count):
                progress = (idx + 1) / float(step_count)
                degrees.append(start + (end - start) * progress)
        last_deg = start
        for frame_idx, deg in enumerate(degrees):
            ok, hard_err, msg, cmd_deg = try_solve(deg)
            if not ok and msg:
                reason = reason or msg
                success = False
            dtheta_used = deg - last_deg
            _record_frame(frame_idx, hard_err, ok, 0, dtheta_used, cmd_deg)
            last_deg = deg
    else:
        direction = 1.0 if end >= start else -1.0
        if step_count is None:
            base_step = float(step or 0.0)
        else:
            if step_count <= 1:
                base_step = end - start
            else:
                base_step = (end - start) / float(step_count - 1)
        dtheta_init = abs(base_step)
        if dtheta_init <= 0:
            dtheta_init = dtheta_min_deg
        dtheta = max(dtheta_min_deg, min(dtheta_init, dtheta_max_deg)) * direction

        theta = start
        if abs(end - start) <= tol:
            ok, hard_err, msg, cmd_deg = try_solve(end)
            if not ok and msg:
                reason = reason or msg
                success = False
            _record_frame(0, hard_err, ok, 0, 0.0, cmd_deg)
        else:
            frame_idx = 0
            while True:
                if direction > 0:
                    if theta >= end - tol:
                        break
                else:
                    if theta <= end + tol:
                        break
                retries = 0
                while True:
                    target = theta + dtheta
                    if direction > 0:
                        target = min(target, end)
                    else:
                        target = max(target, end)
                    snapshot = model.snapshot_state()
                    ok, hard_err, msg, cmd_deg = try_solve(target)
                    if ok and hard_err <= err_good:
                        _record_frame(frame_idx, hard_err, ok, retries, target - theta, cmd_deg)
                        theta = target
                        dtheta = max(dtheta_min_deg, min(abs(dtheta) * grow, dtheta_max_deg)) * direction
                        frame_idx += 1
                        break
                    if ok and hard_err <= err_ok:
                        _record_frame(frame_idx, hard_err, ok, retries, target - theta, cmd_deg)
                        theta = target
                        frame_idx += 1
                        break
                    model.apply_state_snapshot(snapshot)
                    retries += 1
                    if retries > max_retries_per_step:
                        success = False
                        reason = msg or f"adaptive sweep failed near theta={theta:.6g}"
                        break
                    dtheta = max(dtheta_min_deg, abs(dtheta) * shrink) * direction
                if not success:
                    break

    status = {
        "success": success,
        "reason": reason or ("ok" if success else "failed"),
        "solver_error": solver_error or None,
        "solver_error_log": list(solver_error_log),
    }
    summary = {
        "success": success,
        "success_rate": (sum(1 for f in frames if f.get("success")) / float(len(frames))) if frames else 0.0,
        "n_steps": len(frames),
        "max_hard_err": max((f.get("hard_err", 0.0) or 0.0) for f in frames) if frames else 0.0,
    }
    return frames, summary, status
