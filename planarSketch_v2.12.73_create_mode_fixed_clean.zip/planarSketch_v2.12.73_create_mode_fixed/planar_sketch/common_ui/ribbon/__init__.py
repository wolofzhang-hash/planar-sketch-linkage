"""Ribbon helpers."""
