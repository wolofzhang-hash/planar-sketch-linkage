# -*- coding: utf-8 -*-
"""Plot window for sweep/measurement data.

Features:
- Choose X axis: Time / Input / any measurement
- Choose one or multiple Y series (measurements)
- Render in a separate window
- Export SVG and CSV

This module intentionally stays lightweight: it plots the most recently collected sweep
in the Simulation panel.
"""

from __future__ import annotations

import csv
from typing import Dict, List, Any, Optional

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QFileDialog, QMessageBox, QComboBox, QListWidget,
    QListWidgetItem
)

from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure

from .i18n import tr, get_ui_language


def _lang(owner) -> str:
    return get_ui_language(getattr(owner, "_ctrl", None), fallback="zh")


def _tr(owner, key: str, **kwargs) -> str:
    text = tr(_lang(owner), key)
    return text.format(**kwargs) if kwargs else text


class PlotWindow(QMainWindow):
    def __init__(self, records: List[Dict[str, Any]], ctrl=None):
        super().__init__()
        self._ctrl = ctrl
        self.setWindowTitle(_tr(self, "plot.title"))
        self.resize(1000, 650)
        self.setWindowFlag(Qt.WindowType.WindowStaysOnTopHint, True)

        self._records: List[Dict[str, Any]] = records or []
        self._last_x_key: Optional[str] = None
        self._last_y_keys: List[str] = []
        self._marker_lines = []
        self._frame_index = 0

        root = QWidget(self)
        self.setCentralWidget(root)
        layout = QVBoxLayout(root)

        # Controls
        ctrl = QHBoxLayout()
        ctrl.addWidget(QLabel("X:"))
        self.cb_x = QComboBox()
        ctrl.addWidget(self.cb_x, 1)

        ctrl.addWidget(QLabel("Y:"))
        self.lst_y = QListWidget()
        self.lst_y.setSelectionMode(QListWidget.SelectionMode.NoSelection)
        self.lst_y.setMaximumHeight(130)
        ctrl.addWidget(self.lst_y, 2)

        btn_col = QVBoxLayout()
        self.btn_plot = QPushButton("Plot")
        self.btn_export_svg = QPushButton("Export SVG")
        self.btn_export_csv = QPushButton("Export CSV")
        btn_col.addWidget(self.btn_plot)
        btn_col.addWidget(self.btn_export_svg)
        btn_col.addWidget(self.btn_export_csv)
        btn_col.addStretch(1)
        ctrl.addLayout(btn_col)

        layout.addLayout(ctrl)

        # Matplotlib canvas
        self.fig = Figure(figsize=(6, 4))
        self.ax = self.fig.add_subplot(111)
        self.canvas = FigureCanvas(self.fig)
        layout.addWidget(self.canvas, 1)

        self.btn_plot.clicked.connect(self.plot)
        self.btn_export_svg.clicked.connect(self.export_svg)
        self.btn_export_csv.clicked.connect(self.export_csv)

        self._populate_axes_options()

    def bring_to_front(self) -> None:
        if self.isVisible():
            self.raise_()
            self.activateWindow()

    def set_frame_index(self, index: int) -> None:
        self._frame_index = index
        self._update_markers()

    def _populate_axes_options(self):
        self.cb_x.clear()
        self.lst_y.clear()

        if not self._records:
            self.cb_x.addItem("(no data)", None)
            return

        # Collect keys present in records.
        keys = set()
        for r in self._records:
            keys.update(r.keys())

        def is_numeric_key(key: str) -> bool:
            saw_value = False
            for r in self._records:
                v = r.get(key)
                if v is None:
                    continue
                if isinstance(v, bool):
                    return False
                try:
                    float(v)
                except (TypeError, ValueError):
                    return False
                saw_value = True
            return saw_value

        # Preferred ordering
        x_candidates = []
        for k in ["input_deg", "time"]:
            if k in keys:
                x_candidates.append(k)

        # Measurements: anything else numeric-like
        meas = sorted(
            [k for k in keys if k not in {"time", "input_deg"} and is_numeric_key(k)]
        )
        x_candidates.extend(meas)

        def label_for(k: str) -> str:
            if k == "time":
                return "Time"
            if k == "input_deg":
                return "Input (deg)"
            return str(k)

        for k in x_candidates:
            self.cb_x.addItem(label_for(k), k)

        # Y list: measurements (allow multi)
        y_candidates = []
        y_candidates.extend(meas)
        default_y = meas[0] if meas else None

        for k in y_candidates:
            it = QListWidgetItem(label_for(k))
            it.setData(Qt.ItemDataRole.UserRole, k)
            it.setFlags(it.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            it.setCheckState(Qt.CheckState.Checked if default_y and k == default_y else Qt.CheckState.Unchecked)
            self.lst_y.addItem(it)

        if "input_deg" in keys:
            idx = self.cb_x.findData("input_deg")
            if idx >= 0:
                self.cb_x.setCurrentIndex(idx)

    def _selected_y_keys(self) -> List[str]:
        ys: List[str] = []
        for i in range(self.lst_y.count()):
            it = self.lst_y.item(i)
            if it.checkState() == Qt.CheckState.Checked:
                k = it.data(Qt.ItemDataRole.UserRole)
                if k:
                    ys.append(str(k))
        return ys

    def _get_series(self, key: str) -> List[float]:
        out: List[float] = []
        for r in self._records:
            v = r.get(key)
            if v is None or isinstance(v, bool):
                out.append(float("nan"))
                continue
            try:
                out.append(float(v))
            except (TypeError, ValueError):
                out.append(float("nan"))
        return out

    def _clamp_frame_index(self, length: int) -> int:
        if length <= 0:
            return 0
        return max(0, min(self._frame_index, length - 1))

    def _update_markers(self) -> None:
        if not self._records or self._last_x_key is None or not self._last_y_keys:
            return
        if not self._marker_lines or len(self._marker_lines) != len(self._last_y_keys):
            return
        x = self._get_series(self._last_x_key)
        if not x:
            return
        idx = self._clamp_frame_index(len(x))
        for marker, key in zip(self._marker_lines, self._last_y_keys):
            y = self._get_series(key)
            if not y:
                continue
            marker.set_data([x[idx]], [y[idx]])
        self.canvas.draw_idle()

    def plot(self):
        if not self._records:
            QMessageBox.information(self, _tr(self, "plot.title"), _tr(self, "plot.msg.no_sweep_data"))
            return

        x_key = self.cb_x.currentData()
        if not x_key:
            return
        y_keys = self._selected_y_keys()
        if not y_keys:
            QMessageBox.information(self, _tr(self, "plot.title"), _tr(self, "plot.msg.no_y_selected"))
            return

        self._last_x_key = str(x_key)
        self._last_y_keys = [str(k) for k in y_keys]

        x = self._get_series(self._last_x_key)

        self.ax.clear()
        self._marker_lines = []
        idx = self._clamp_frame_index(len(x))
        for k in self._last_y_keys:
            y = self._get_series(k)
            line = self.ax.plot(x, y, label=k)[0]
            marker = self.ax.plot([x[idx]], [y[idx]], marker="o", linestyle="None", color=line.get_color())[0]
            self._marker_lines.append(marker)
        self.ax.set_xlabel(self.cb_x.currentText())
        self.ax.set_ylabel("Value")
        if len(self._last_y_keys) > 1:
            self.ax.legend()
        self.ax.grid(True)
        self.canvas.draw_idle()

    def export_svg(self):
        if not self._records:
            QMessageBox.information(self, _tr(self, "export.title"), _tr(self, "plot.msg.no_data_export"))
            return
        if self._last_x_key is None:
            self.plot()
        path, _ = QFileDialog.getSaveFileName(self, "Export SVG", "", "SVG (*.svg)")
        if not path:
            return
        if not path.lower().endswith(".svg"):
            path += ".svg"
        try:
            self.fig.savefig(path, format="svg")
        except Exception as e:
            QMessageBox.critical(self, _tr(self, "export.failed"), str(e))

    def export_csv(self):
        if not self._records:
            QMessageBox.information(self, _tr(self, "export.title"), _tr(self, "plot.msg.no_data_export"))
            return
        if self._last_x_key is None:
            self.plot()
        if self._last_x_key is None:
            return
        if not self._last_y_keys:
            QMessageBox.information(self, _tr(self, "export.title"), _tr(self, "plot.msg.no_y_export"))
            return

        path, _ = QFileDialog.getSaveFileName(self, "Export CSV", "", "CSV (*.csv)")
        if not path:
            return
        if not path.lower().endswith(".csv"):
            path += ".csv"
        try:
            with open(path, "w", newline="", encoding="utf-8") as f:
                w = csv.writer(f)
                header = [self._last_x_key] + self._last_y_keys
                w.writerow(header)
                for r in self._records:
                    row = [r.get(self._last_x_key)]
                    for k in self._last_y_keys:
                        row.append(r.get(k))
                    w.writerow(row)
        except Exception as e:
            QMessageBox.critical(self, _tr(self, "export.failed"), str(e))
